
RCLONE_BIN = "/usr/bin/rclone"
LOG_FILE = "logs/app.log"
DEFAULT_PARALLEL_TASKS = 4
