# Struttura del Progetto

Descrizione della struttura della cartella.