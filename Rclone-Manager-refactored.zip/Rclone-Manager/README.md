# Rclone Manager

Un'interfaccia Flask per gestire task con Rclone.